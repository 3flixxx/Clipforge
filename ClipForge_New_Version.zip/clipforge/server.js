import express from "express";
import session from "express-session";
import SQLiteStoreFactory from "connect-sqlite3";
import Database from "better-sqlite3";
import bcrypt from "bcryptjs";
import helmet from "helmet";
import crypto from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";
import fs from "node:fs";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.join(__dirname, "data");
fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "clipforge.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 username TEXT NOT NULL COLLATE NOCASE UNIQUE,
 email TEXT NOT NULL COLLATE NOCASE UNIQUE,
 password_hash TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS tournaments (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 name TEXT NOT NULL, type TEXT NOT NULL DEFAULT 'Other', event_date TEXT NOT NULL DEFAULT '',
 input_mode TEXT NOT NULL DEFAULT 'totals', kills INTEGER NOT NULL DEFAULT 0, points REAL NOT NULL DEFAULT 0,
 wins INTEGER NOT NULL DEFAULT 0, placement INTEGER, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS tournament_matches (
 id INTEGER PRIMARY KEY AUTOINCREMENT, tournament_id INTEGER NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, match_number INTEGER NOT NULL DEFAULT 1,
 kills INTEGER NOT NULL DEFAULT 0, points REAL NOT NULL DEFAULT 0, wins INTEGER NOT NULL DEFAULT 0,
 placement INTEGER, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS practice_matches (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 practice_type TEXT NOT NULL CHECK(practice_type IN ('Scrims','Cup Endgame')),
 name TEXT NOT NULL DEFAULT '', match_date TEXT NOT NULL DEFAULT '', kills INTEGER NOT NULL DEFAULT 0,
 points REAL NOT NULL DEFAULT 0, wins INTEGER NOT NULL DEFAULT 0, placement INTEGER,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS ranked_matches (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 mode TEXT NOT NULL CHECK(mode IN ('BR Builds','BR Zero Build','Reload Builds','Reload Zero Build')),
 match_date TEXT NOT NULL DEFAULT '', rank_name TEXT NOT NULL DEFAULT '', kills INTEGER NOT NULL DEFAULT 0,
 placement INTEGER, match_points REAL NOT NULL DEFAULT 0, notes TEXT NOT NULL DEFAULT '',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS scoring_rules (
 user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
 points_weight REAL NOT NULL DEFAULT 0.8, kills_weight REAL NOT NULL DEFAULT 2.5,
 wins_weight REAL NOT NULL DEFAULT 25, placement_weight REAL NOT NULL DEFAULT 8,
 fncs_multiplier REAL NOT NULL DEFAULT 2
);
CREATE TABLE IF NOT EXISTS organizations (
 id INTEGER PRIMARY KEY AUTOINCREMENT, owner_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 name TEXT NOT NULL, tag TEXT NOT NULL COLLATE NOCASE UNIQUE, description TEXT NOT NULL DEFAULT '',
 region TEXT NOT NULL DEFAULT '', goals TEXT NOT NULL DEFAULT '', recruiting INTEGER NOT NULL DEFAULT 1,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS organization_members (
 organization_id INTEGER NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 role TEXT NOT NULL DEFAULT 'Member', joined_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (organization_id,user_id)
);
CREATE TABLE IF NOT EXISTS player_listings (
 id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
 listing_type TEXT NOT NULL DEFAULT 'Player', modes TEXT NOT NULL DEFAULT 'Duos,Trios,Squads',
 role TEXT NOT NULL DEFAULT 'Any', region TEXT NOT NULL DEFAULT '', goals TEXT NOT NULL DEFAULT '',
 description TEXT NOT NULL DEFAULT '', active INTEGER NOT NULL DEFAULT 1,
 updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

const app = express();
app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "200kb" }));
const SQLiteStore = SQLiteStoreFactory(session);
const production = process.env.NODE_ENV === "production";
const secret = process.env.SESSION_SECRET;
if (production && (!secret || secret.length < 32)) {
  console.error("Set SESSION_SECRET to a random string of at least 32 characters before production.");
  process.exit(1);
}
app.use(session({
  store: new SQLiteStore({ db: "sessions.sqlite", dir: dataDir }),
  secret: secret || "development-only-change-this-secret-before-deploying",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: production, maxAge: 7 * 24 * 60 * 60 * 1000 }
}));
app.use(express.static(path.join(__dirname, "public")));

const safeUser = u => ({ id: u.id, username: u.username, createdAt: u.created_at });
const currentUser = req => req.session.userId ? db.prepare("SELECT id,username,email,created_at FROM users WHERE id=?").get(req.session.userId) : null;
function auth(req,res,next) { if (!currentUser(req)) return res.status(401).json({error:"Please log in first."}); next(); }
function number(v, min=0, max=1_000_000) { const n=Number(v); return Number.isFinite(n) ? Math.max(min,Math.min(max,n)) : 0; }
function int(v,min=0,max=1_000_000) { return Math.round(number(v,min,max)); }
function str(v,max=180) { return String(v ?? "").trim().slice(0,max); }
function positiveId(v) { const n=Number(v); return Number.isInteger(n)&&n>0?n:0; }
function eventPR(t,rules) {
 const place = Number(t.placement);
 const placementScore = !Number.isFinite(place) || place <= 0 ? 0 : place===1?100:place===2?75:place===3?60:place<=5?45:place<=10?30:place<=15?20:place<=25?10:5;
 const base = number(t.points)*rules.points_weight + number(t.kills)*rules.kills_weight + number(t.wins)*rules.wins_weight + placementScore*rules.placement_weight/10;
 return Math.round(base * (/fncs/i.test(t.type||"") ? rules.fncs_multiplier : 1));
}
function tournamentRows(userId) {
 const rows = db.prepare("SELECT * FROM tournaments WHERE user_id=? ORDER BY event_date DESC,id DESC").all(userId);
 const matches = db.prepare("SELECT * FROM tournament_matches WHERE user_id=? ORDER BY match_number,id").all(userId);
 const byTournament = new Map();
 for (const m of matches) { if(!byTournament.has(m.tournament_id)) byTournament.set(m.tournament_id,[]); byTournament.get(m.tournament_id).push(m); }
 return rows.map(t => {
   const ms = byTournament.get(t.id)||[];
   const fromMatches = t.input_mode==="matches" && ms.length>0;
   const out = {...t, matches:ms};
   if(fromMatches) { out.kills=ms.reduce((s,m)=>s+m.kills,0); out.points=ms.reduce((s,m)=>s+m.points,0); out.wins=ms.reduce((s,m)=>s+m.wins,0); }
   return out;
 });
}
function statsFor(userId) {
 const ts=tournamentRows(userId);
 const rules=db.prepare("SELECT * FROM scoring_rules WHERE user_id=?").get(userId) || {points_weight:.8,kills_weight:2.5,wins_weight:25,placement_weight:8,fncs_multiplier:2};
 const official={tournaments:ts.length,kills:ts.reduce((s,t)=>s+t.kills,0),points:ts.reduce((s,t)=>s+t.points,0),wins:ts.reduce((s,t)=>s+t.wins,0),pr:ts.reduce((s,t)=>s+eventPR(t,rules),0)};
 const practice=db.prepare("SELECT practice_type,COUNT(*) count,COALESCE(SUM(kills),0) kills,COALESCE(SUM(points),0) points,COALESCE(SUM(wins),0) wins FROM practice_matches WHERE user_id=? GROUP BY practice_type").all(userId);
 const ranked=db.prepare("SELECT mode,COUNT(*) count,COALESCE(SUM(kills),0) kills,COALESCE(SUM(match_points),0) points FROM ranked_matches WHERE user_id=? GROUP BY mode").all(userId);
 return {official,practice,ranked};
}
function ownedTournament(req,res,next) {
 const id=positiveId(req.params.id); const t=db.prepare("SELECT * FROM tournaments WHERE id=? AND user_id=?").get(id,req.session.userId);
 if(!t) return res.status(404).json({error:"Tournament not found."}); req.tournament=t; next();
}

app.get("/api/health",(req,res)=>res.json({ok:true,app:"ClipForge"}));
app.post("/api/auth/signup", async (req,res)=>{
 const username=str(req.body.username,24), email=str(req.body.email,254).toLowerCase(), password=String(req.body.password||"");
 if(!/^[a-zA-Z0-9_]{3,24}$/.test(username)) return res.status(400).json({error:"Username must be 3–24 letters, numbers, or underscores."});
 if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({error:"Enter a valid email address."});
 if(password.length<10) return res.status(400).json({error:"Password must be at least 10 characters."});
 try {
  const hash=await bcrypt.hash(password,12);
  const info=db.prepare("INSERT INTO users(username,email,password_hash) VALUES(?,?,?)").run(username,email,hash);
  const id=Number(info.lastInsertRowid); db.prepare("INSERT INTO scoring_rules(user_id) VALUES(?)").run(id);
  req.session.userId=id; res.json({user:{id,username}});
 } catch(e) { res.status(409).json({error:"That username or email is already registered."}); }
});
app.post("/api/auth/login", async (req,res)=>{
 const login=str(req.body.login,254), password=String(req.body.password||"");
 const u=db.prepare("SELECT * FROM users WHERE username=? COLLATE NOCASE OR email=? COLLATE NOCASE").get(login,login);
 if(!u || !(await bcrypt.compare(password,u.password_hash))) return res.status(401).json({error:"Incorrect username/email or password."});
 req.session.regenerate(err=>{if(err)return res.status(500).json({error:"Could not start session."}); req.session.userId=u.id; res.json({user:safeUser(u)});});
});
app.post("/api/auth/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/me",(req,res)=>{const u=currentUser(req);res.json({user:u?safeUser(u):null});});
app.get("/api/profile/:username",(req,res)=>{
 const u=db.prepare("SELECT id,username,created_at FROM users WHERE username=? COLLATE NOCASE").get(str(req.params.username,24));
 if(!u)return res.status(404).json({error:"Profile not found."});
 const s=statsFor(u.id); res.json({profile:{...safeUser(u),stats:s.official,listing:db.prepare("SELECT listing_type,modes,role,region,goals,description,active FROM player_listings WHERE user_id=? AND active=1").get(u.id)||null}});
});
app.get("/api/dashboard",auth,(req,res)=>{const u=currentUser(req);const recent=tournamentRows(u.id).slice(0,5);res.json({user:safeUser(u),stats:statsFor(u.id),recent});});

app.get("/api/tournaments",auth,(req,res)=>res.json({tournaments:tournamentRows(req.session.userId)}));
app.post("/api/tournaments",auth,(req,res)=>{
 const b=req.body||{},name=str(b.name,120);if(!name)return res.status(400).json({error:"Tournament name is required."});
 const mode=b.input_mode==="matches"?"matches":"totals";
 const info=db.prepare("INSERT INTO tournaments(user_id,name,type,event_date,input_mode,kills,points,wins,placement) VALUES(?,?,?,?,?,?,?,?,?)")
 .run(req.session.userId,name,str(b.type||"Other",60),str(b.event_date,10),mode,int(b.kills),number(b.points),int(b.wins),b.placement===""||b.placement==null?null:int(b.placement,1,10000));
 res.json({tournament:tournamentRows(req.session.userId).find(t=>t.id===Number(info.lastInsertRowid))});
});
app.put("/api/tournaments/:id",auth,ownedTournament,(req,res)=>{
 const b=req.body||{},name=str(b.name,120);if(!name)return res.status(400).json({error:"Tournament name is required."});
 const mode=b.input_mode==="matches"?"matches":"totals";
 db.prepare("UPDATE tournaments SET name=?,type=?,event_date=?,input_mode=?,kills=?,points=?,wins=?,placement=? WHERE id=? AND user_id=?")
 .run(name,str(b.type||"Other",60),str(b.event_date,10),mode,int(b.kills),number(b.points),int(b.wins),b.placement===""||b.placement==null?null:int(b.placement,1,10000),req.tournament.id,req.session.userId);
 res.json({tournament:tournamentRows(req.session.userId).find(t=>t.id===req.tournament.id)});
});
app.delete("/api/tournaments/:id",auth,ownedTournament,(req,res)=>{db.prepare("DELETE FROM tournaments WHERE id=? AND user_id=?").run(req.tournament.id,req.session.userId);res.json({ok:true});});
app.get("/api/tournaments/:id/matches",auth,ownedTournament,(req,res)=>res.json({matches:db.prepare("SELECT * FROM tournament_matches WHERE tournament_id=? AND user_id=? ORDER BY match_number,id").all(req.tournament.id,req.session.userId)}));
app.post("/api/tournaments/:id/matches",auth,ownedTournament,(req,res)=>{
 const b=req.body||{};const n=int(b.match_number,1,1000);
 const info=db.prepare("INSERT INTO tournament_matches(tournament_id,user_id,match_number,kills,points,wins,placement) VALUES(?,?,?,?,?,?,?)").run(req.tournament.id,req.session.userId,n,int(b.kills),number(b.points),int(b.wins),b.placement===""||b.placement==null?null:int(b.placement,1,10000));
 db.prepare("UPDATE tournaments SET input_mode='matches' WHERE id=? AND user_id=?").run(req.tournament.id,req.session.userId);
 res.json({match:db.prepare("SELECT * FROM tournament_matches WHERE id=?").get(Number(info.lastInsertRowid)),tournament:tournamentRows(req.session.userId).find(t=>t.id===req.tournament.id)});
});
app.put("/api/tournament-matches/:id",auth,(req,res)=>{
 const id=positiveId(req.params.id),m=db.prepare("SELECT * FROM tournament_matches WHERE id=? AND user_id=?").get(id,req.session.userId);if(!m)return res.status(404).json({error:"Match not found."});
 const b=req.body||{};db.prepare("UPDATE tournament_matches SET match_number=?,kills=?,points=?,wins=?,placement=? WHERE id=? AND user_id=?").run(int(b.match_number,1,1000),int(b.kills),number(b.points),int(b.wins),b.placement===""||b.placement==null?null:int(b.placement,1,10000),id,req.session.userId);res.json({ok:true});
});
app.delete("/api/tournament-matches/:id",auth,(req,res)=>{const info=db.prepare("DELETE FROM tournament_matches WHERE id=? AND user_id=?").run(positiveId(req.params.id),req.session.userId);if(!info.changes)return res.status(404).json({error:"Match not found."});res.json({ok:true});});

app.get("/api/scoring",auth,(req,res)=>res.json({rules:db.prepare("SELECT points_weight,kills_weight,wins_weight,placement_weight,fncs_multiplier FROM scoring_rules WHERE user_id=?").get(req.session.userId)}));
app.put("/api/scoring",auth,(req,res)=>{
 const b=req.body||{};db.prepare("UPDATE scoring_rules SET points_weight=?,kills_weight=?,wins_weight=?,placement_weight=?,fncs_multiplier=? WHERE user_id=?").run(number(b.points_weight,0,100),number(b.kills_weight,0,100),number(b.wins_weight,0,1000),number(b.placement_weight,0,100),number(b.fncs_multiplier,1,10),req.session.userId);
 res.json({rules:db.prepare("SELECT points_weight,kills_weight,wins_weight,placement_weight,fncs_multiplier FROM scoring_rules WHERE user_id=?").get(req.session.userId)});
});

app.get("/api/practice",auth,(req,res)=>res.json({matches:db.prepare("SELECT * FROM practice_matches WHERE user_id=? ORDER BY match_date DESC,id DESC").all(req.session.userId)}));
app.post("/api/practice",auth,(req,res)=>{
 const b=req.body||{};if(!["Scrims","Cup Endgame"].includes(b.practice_type))return res.status(400).json({error:"Choose Scrims or Cup Endgame."});
 const info=db.prepare("INSERT INTO practice_matches(user_id,practice_type,name,match_date,kills,points,wins,placement) VALUES(?,?,?,?,?,?,?,?)").run(req.session.userId,b.practice_type,str(b.name,120),str(b.match_date,10),int(b.kills),number(b.points),int(b.wins),b.placement===""||b.placement==null?null:int(b.placement,1,10000));
 res.json({match:db.prepare("SELECT * FROM practice_matches WHERE id=?").get(Number(info.lastInsertRowid))});
});
app.put("/api/practice/:id",auth,(req,res)=>{
 const id=positiveId(req.params.id),m=db.prepare("SELECT id FROM practice_matches WHERE id=? AND user_id=?").get(id,req.session.userId);if(!m)return res.status(404).json({error:"Practice match not found."});
 const b=req.body||{};if(!["Scrims","Cup Endgame"].includes(b.practice_type))return res.status(400).json({error:"Choose Scrims or Cup Endgame."});
 db.prepare("UPDATE practice_matches SET practice_type=?,name=?,match_date=?,kills=?,points=?,wins=?,placement=? WHERE id=? AND user_id=?").run(b.practice_type,str(b.name,120),str(b.match_date,10),int(b.kills),number(b.points),int(b.wins),b.placement===""||b.placement==null?null:int(b.placement,1,10000),id,req.session.userId);res.json({ok:true});
});
app.delete("/api/practice/:id",auth,(req,res)=>{const r=db.prepare("DELETE FROM practice_matches WHERE id=? AND user_id=?").run(positiveId(req.params.id),req.session.userId);if(!r.changes)return res.status(404).json({error:"Practice match not found."});res.json({ok:true});});

const modes=["BR Builds","BR Zero Build","Reload Builds","Reload Zero Build"];
app.get("/api/ranked",auth,(req,res)=>res.json({matches:db.prepare("SELECT * FROM ranked_matches WHERE user_id=? ORDER BY match_date DESC,id DESC").all(req.session.userId),modes}));
app.post("/api/ranked",auth,(req,res)=>{
 const b=req.body||{};if(!modes.includes(b.mode))return res.status(400).json({error:"Choose one of the four ranked modes."});
 const info=db.prepare("INSERT INTO ranked_matches(user_id,mode,match_date,rank_name,kills,placement,match_points,notes) VALUES(?,?,?,?,?,?,?,?)").run(req.session.userId,b.mode,str(b.match_date,10),str(b.rank_name,60),int(b.kills),b.placement===""||b.placement==null?null:int(b.placement,1,10000),number(b.match_points),str(b.notes,300));
 res.json({match:db.prepare("SELECT * FROM ranked_matches WHERE id=?").get(Number(info.lastInsertRowid))});
});
app.put("/api/ranked/:id",auth,(req,res)=>{
 const id=positiveId(req.params.id),m=db.prepare("SELECT id FROM ranked_matches WHERE id=? AND user_id=?").get(id,req.session.userId);if(!m)return res.status(404).json({error:"Ranked match not found."});
 const b=req.body||{};if(!modes.includes(b.mode))return res.status(400).json({error:"Choose one of the four ranked modes."});
 db.prepare("UPDATE ranked_matches SET mode=?,match_date=?,rank_name=?,kills=?,placement=?,match_points=?,notes=? WHERE id=? AND user_id=?").run(b.mode,str(b.match_date,10),str(b.rank_name,60),int(b.kills),b.placement===""||b.placement==null?null:int(b.placement,1,10000),number(b.match_points),str(b.notes,300),id,req.session.userId);res.json({ok:true});
});
app.delete("/api/ranked/:id",auth,(req,res)=>{const r=db.prepare("DELETE FROM ranked_matches WHERE id=? AND user_id=?").run(positiveId(req.params.id),req.session.userId);if(!r.changes)return res.status(404).json({error:"Ranked match not found."});res.json({ok:true});});

app.get("/api/organizations", (req,res)=>res.json({organizations:db.prepare("SELECT o.id,o.name,o.tag,o.description,o.region,o.goals,o.recruiting,u.username owner FROM organizations o JOIN users u ON u.id=o.owner_id ORDER BY o.id DESC").all()}));
app.post("/api/organizations",auth,(req,res)=>{
 const b=req.body||{},name=str(b.name,80),tag=str(b.tag,6).toUpperCase();
 if(!name||!/^[A-Z0-9]{2,6}$/.test(tag))return res.status(400).json({error:"Enter a name and a 2–6 character letters/numbers tag."});
 try {const info=db.prepare("INSERT INTO organizations(owner_id,name,tag,description,region,goals,recruiting) VALUES(?,?,?,?,?,?,?)").run(req.session.userId,name,tag,str(b.description,500),str(b.region,80),str(b.goals,300),b.recruiting===false?0:1);db.prepare("INSERT INTO organization_members(organization_id,user_id,role) VALUES(?,?,'Owner')").run(Number(info.lastInsertRowid),req.session.userId);res.json({id:Number(info.lastInsertRowid)});}catch(e){res.status(409).json({error:"That organization tag is already in use."});}
});
app.post("/api/organizations/:id/join",auth,(req,res)=>{
 const id=positiveId(req.params.id),o=db.prepare("SELECT id,recruiting FROM organizations WHERE id=?").get(id);if(!o)return res.status(404).json({error:"Organization not found."});if(!o.recruiting)return res.status(400).json({error:"This organization is not recruiting."});
 try{db.prepare("INSERT INTO organization_members(organization_id,user_id,role) VALUES(?,?,'Member')").run(id,req.session.userId);res.json({ok:true});}catch(e){res.status(409).json({error:"You're already a member of this organization."});}
});
app.get("/api/organizations/mine",auth,(req,res)=>res.json({organizations:db.prepare("SELECT o.*,m.role FROM organizations o JOIN organization_members m ON m.organization_id=o.id WHERE m.user_id=? ORDER BY o.id DESC").all(req.session.userId)}));

app.get("/api/listing",auth,(req,res)=>res.json({listing:db.prepare("SELECT listing_type,modes,role,region,goals,description,active FROM player_listings WHERE user_id=?").get(req.session.userId)||null}));
app.put("/api/listing",auth,(req,res)=>{
 const b=req.body||{};db.prepare(`INSERT INTO player_listings(user_id,listing_type,modes,role,region,goals,description,active,updated_at) VALUES(?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
 ON CONFLICT(user_id) DO UPDATE SET listing_type=excluded.listing_type,modes=excluded.modes,role=excluded.role,region=excluded.region,goals=excluded.goals,description=excluded.description,active=excluded.active,updated_at=CURRENT_TIMESTAMP`)
 .run(req.session.userId,str(b.listing_type||"Player",30),str(b.modes||"Duos,Trios,Squads",120),str(b.role||"Any",50),str(b.region,80),str(b.goals,300),str(b.description,500),b.active===false?0:1);
 res.json({ok:true});
});
app.get("/api/players",(req,res)=>{
 const listings=db.prepare("SELECT p.user_id,p.listing_type,p.modes,p.role,p.region,p.goals,p.description,u.username FROM player_listings p JOIN users u ON u.id=p.user_id WHERE p.active=1 ORDER BY p.updated_at DESC").all();
 res.json({players:listings});
});
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
const port=Number(process.env.PORT)||3000;
app.listen(port,"0.0.0.0",()=>console.log(`ClipForge listening on port ${port}`));
