# Deployment checklist

- [ ] Use a Node.js host with Node 20+ and a persistent writable disk.
- [ ] Set `NODE_ENV=production`.
- [ ] Set `SESSION_SECRET` to a long random secret (32+ characters).
- [ ] Ensure `data/` persists across redeploys/restarts.
- [ ] Use HTTPS.
- [ ] Test sign-up, login, logout, tournament CRUD, match CRUD, practice isolation, ranked CRUD, scoring, organization creation, and user-to-user data isolation.
- [ ] Back up the SQLite database regularly.
- [ ] For public production use, add rate limiting, email verification, password reset, security monitoring, and a managed database as needed.

Do not put `.env` or database files into a public repository.
