# ClipForge

A full-stack starter for a Fortnite esports stats and team platform. It includes real account authentication, server-side authorization, persistent SQLite storage, tournament/practice/ranked tracking, scoring rules, organizations, recruitment listings, and a clean responsive UI. It ships with **no seeded/demo users, tournaments, or stats**.

## Requirements
- Node.js 20+
- npm

## Run locally
1. Copy `.env.example` to `.env` and set `SESSION_SECRET` to a long random value.
2. Run `npm install`
3. Run `npm start`
4. Open `http://localhost:3000`

The database file `data/clipforge.sqlite` is created automatically and persists between restarts. Back it up before changing hosting environments.

## Deployment
Deploy to a Node.js host that supports a persistent writable disk. Set `SESSION_SECRET` and `NODE_ENV=production`. Use HTTPS in production. If hosting on an ephemeral filesystem, configure a persistent volume for the `data/` directory or switch the database adapter to a managed persistent database before launch.

## Included features
- Signup/login/logout with bcrypt password hashing and HTTP-only session cookies.
- Server-side user scoping for personal data; public profiles never return email addresses.
- Tournament records and optional individual match records; totals can be calculated from matches or entered as event totals.
- Configurable scoring weights and recalculation from saved results.
- Separate Scrims and Cup Endgame practice records and practice PR.
- Four distinct ranked modes and editable/deletable matches.
- Organizations with tags, descriptions, region, recruitment status, owner/manager membership roles, and public discovery.
- Public player/coach listings with role, mode, region, and goals.
- Dashboard values derived from saved database records, not demo data.

## Important notes
- This is a deployable foundation, not a claim of verified production deployment. Run the checks below and test it in your intended hosting environment before inviting users.
- The PR formula is ClipForge's own configurable formula, not official Fortnite PR.
- No Epic account integration or official Fortnite stats API is included. Results are entered manually.
- Logo upload, organization applications/invites, and automated account recovery/email verification are not included in this initial build.
- SQLite is suitable for a small deployment on persistent disk. For a larger public service, move to a managed PostgreSQL database and add rate limiting, email verification, password reset, logging, backups, and abuse reporting.
- There are no fake/demo records. A new account begins with zero stats and empty lists.
